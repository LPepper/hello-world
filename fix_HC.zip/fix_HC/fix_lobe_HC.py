
import sys,os
import numpy as np

from data_proc.wjydetector.huaxi_classifier import Classifier

from random import randint, shuffle
from tqdm import tqdm
from couchbase.cluster import Cluster, PasswordAuthenticator
from couchbase.n1ql import N1QLQuery
import hashlib
import random
import json
import SimpleITK as sitk
from LungSegmentsSeg.segments import lobar_segment_partition
from Lobeseg.lobesegment_HC import LobeSegmentor_HC
from config import MODEL_PATH,DCM_PATH

cluster = Cluster('couchbase://192.168.7.175')
authenticator = PasswordAuthenticator('deepln', 'jevoislavieenrose')
cluster.authenticate(authenticator)

cb = cluster.open_bucket('deepln')


rects = cb.n1ql_query(N1QLQuery("select rects,caseId from `deepln` where type = 'draft'"))





if __name__ == "__main__":
    flag = 0
    lobeSegmentor_HC = LobeSegmentor_HC(MODEL_PATH + 'lobe_HC.pth')

    gpu = sys.argv[1]
    os.environ["CUDA_VISIBLE_DEVICES"] = gpu




def find_nearest_nonzero(img, TARGET):
    nonzero = np.argwhere(img > 0)
    distances = np.sqrt((nonzero[:,0] - TARGET[0]) ** 2 + (nonzero[:,1] - TARGET[1]) ** 2  + (nonzero[:,2] - TARGET[2]) **2)
    nearest_index = np.argmin(distances)
    return nonzero[nearest_index]

def get_image_slice_spacing(path):
    reader = sitk.ImageSeriesReader()
    dcm_names = reader.GetGDCMSeriesFileNames(path)
    reader.SetFileNames(dcm_names)
    image = reader.Execute()
    image_array = sitk.GetArrayFromImage(image)
    tmp_spacing = image.GetSpacing()
    tmp_origin = image.GetOrigin()
    
    
    return image_array,image_array.shape[0], tmp_spacing,tmp_origin

def get_lung(path):
    itkimage = sitk.ReadImage(os.path.join(path,'segmentation_lung.mha'))
    lung = sitk.GetArrayFromImage(itkimage)
    return lung



for row in tqdm(rects):
    nodule_keys = row['rects']
    caseId = row['caseId']
    
    if  'HC'not in caseId:
        continue
    
    if 1:
        #read dicom
        image_array,total_slice, spacing,origin = get_image_slice_spacing(os.path.join(DCM_PATH, caseId))
        path = os.path.join(DCM_PATH, caseId)
        lung = get_lung(path)
        #segment the lobe                    
        lobe_mask = lobeSegmentor_HC(image_array,lung,spacing,origin,path)
        
        print('segment the lobe')
        
        for i in range(len(nodule_keys)):
            nodule_key_i = nodule_keys[i]
            try:
                nodule_info = cb.get(nodule_key_i).value
                
            except:
                continue

            
            
       
            
            #fix lobe pos
            
            if os.path.exists(os.path.join(DCM_PATH, caseId,'segmentation_lung.mha')):



                #get pos info
                slice_num = nodule_info['slice_idx']

                x1 = nodule_info['x1']
                #x2 = nodule_info['x2']
                y1 = nodule_info['y1']
                #y2 = nodule_info['y2']
                diameter = nodule_info['diameter']



                diameter = diameter / spacing[1]

                z = float(total_slice - slice_num - 1)
                y = float(y1 + diameter/2)
                x = float(x1 + diameter/2)

                lobe_pos = lobe_mask[int(z),int(y),int(x)]
                if int(lobe_pos) == 0:
                    nearest_cood = find_nearest_nonzero(lobe_mask,(int(z),int(y),int(x)))
                    lobe_pos = lobe_mask[nearest_cood[0],nearest_cood[1],nearest_cood[2]]

                nodule_info['place'] = int(lobe_pos)
                #get the lung segement position of nodule

                segment_pos = ''
                segment_pos = lobar_segment_partition(lobe_mask,[int(z),int(y),int(x)],int(lobe_pos))
                nodule_info['segment'] = str(segment_pos)
                print('fix nodule position in lobe and segment:',nodule_key_i)
                
                
        
            cb.upsert(nodule_key_i,nodule_info)
    
    
    



